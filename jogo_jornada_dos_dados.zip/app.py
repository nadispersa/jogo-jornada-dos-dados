import streamlit as st

st.set_page_config(page_title="A Jornada dos Dados", page_icon="📊")

st.title("🐑 A Jornada dos Dados")

st.image("img/ovelha_mend.png", width=250)

st.markdown("""
Você acorda em uma biblioteca antiga, coberta por poeira e silêncio...  
Em cima da mesa, um envelope selado com cera:

**“Convocação urgente! O Reino dos Dados está em perigo.”**
""")

escolha = st.radio("O que você quer fazer?", ["Abrir o envelope", "Ignorar e voltar a dormir"])

if escolha == "Abrir o envelope":
    st.success("Você acaba de aceitar o desafio! A Ovelha Mend aparece!")
    st.image("img/ovelha_mend_feliz.png", width=250)
elif escolha == "Ignorar e voltar a dormir":
    st.warning("Você volta a dormir e... perde a chance de salvar os dados 😢")
